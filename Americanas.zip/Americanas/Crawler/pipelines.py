# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
# import MySQLdb

from sqlalchemy.orm import sessionmaker
from scrapy.exceptions import DropItem, CloseSpider
from Crawler.models import Add, db_connect, create_table
import logging


class DuplicatesPipeline(object):

    def __init__(self):
        """
        Initializes database connection and sessionmaker.
        Creates tables.
        """
        engine = db_connect()
        create_table(engine)
        self.Session = sessionmaker(bind=engine)
        logging.info("****DuplicatesPipeline: database connected****")

    def process_item(self, item, spider):
        session = self.Session()
        add = session.query(Add).filter_by(
            url=item["url"]).first()
        if add is not None:  # the current quote exists
            # spider.logger.info("Closing Spider Because no New Product")
            # raise CloseSpider
            # spider.flag_start_urls[item["start_url_index"]] = False
            # session.close()
            raise DropItem("Duplicate item found: %s" % item["url"])

        else:
            session.close()
            return item


class ImobPipeline(object):
    def __init__(self):
        """
        Initializes database connection and sessionmaker
        Creates tables
        """

        engine = db_connect()
        create_table(engine)
        self.Session = sessionmaker(bind=engine)
        logging.info("****SaveCarsPipeline: database connected****")

    def process_item(self, item, spider):

        spider.logger.info(
            f"Adding New Add, Add URL {item['url']} ")

        session = self.Session()
        add = Add()

        add.url = item['url']

        add.Title = item['Title']
        add.Price = item['Price']
        add.Description = item['Description']
        add.ProductID = item['ProductID']
        add.Sellername = item['Sellername']
        add.SellerID = item['SellerID']
        add.MainImage = item["MainImage"]
        add.Image1 = item['Image1']
        add.Image2 = item['Image2']
        add.Image3 = item['Image3']
        add.Image4 = item['Image4']
        add.shipping = item['shipping']
        add.Date = item['Date']

        spider.logger.info(add.__dict__)

        try:
            session.add(add)
            session.commit()

        except:
            session.rollback()
            raise

        finally:
            session.close()

        return item

    def close_spider(self, spider):
        pass
        # spider.logger.info('Scrapping has ended')
        # try:
        #     # self.engine.dispose()
        #     spider.logger.info("Engine Disposed of Class SaveCarsPipleine")
        # except Exception as e:
        #     spider.logger.info(
        #         "Engine Disposed Failed of Class SaveCarsPipleine")
        #     spider.logger.info(e)
