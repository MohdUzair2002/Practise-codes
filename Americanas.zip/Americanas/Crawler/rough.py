def open_spider(self, spider):
    spider.logger.info('Spider opened: %s' % spider.name)

    session = self.Session()

    cars = session.query(Car.id).all()
    cars_id_list = [x for x in cars]
    session.close()

    spider.logger.info(
        'Updating the tables and doing calulations, please wait')
    last_3months = datetime.now() - relativedelta(months=3)
    for car1_id in cars_id_list:
        session = self.Session()
        spider.logger.info(f"Working on Car ID => {car1_id}")

        car1 = session.query(Car).filter_by(
            id=car1_id[0]
        ).one()

        print(f"Row no.s {car1} {type(cars)}")

        # car_model_count = session.query(Car).filter_by(
        #     car_model=car1.car_model).count()

        # car model median price

        cars_with_same_model = session.query(Car.car_price).filter_by(
            car_model=car1.car_model,
            car_mileage=car1.car_mileage,
            engine_cc=car1.engine_cc,
            car_model_year=car1.car_model_year
        ).all()

        print(
            f"cars_with_same_model lens no.s {len(cars_with_same_model)} {type(cars_with_same_model)}")

        car_prices = [int(x[0]) for x in cars_with_same_model]

        car_model_median_price = statistics.median(car_prices)

        # car_model_max_price

        car_model_max_price = max(car_prices)

        # car_model_min_price
        car_model_min_price = min(car_prices)

        # car_model_divergence_price

        car_model_divergence_price = round(100 -
                                           ((int(car1.car_price)/car_model_median_price)*100), 2)

        # Setting the new values

        car1.car_model_count = len(cars_with_same_model)
        car1.car_model_median_price = car_model_median_price
        car1.car_model_max_price = car_model_max_price
        car1.car_model_min_price = car_model_min_price
        car1.car_model_divergence_price = car_model_divergence_price

        cars_with_same_model_last3Months = session.query(Car.car_price).filter_by(
            car_model=car1.car_model,
            car_mileage=car1.car_mileage,
            engine_cc=car1.engine_cc,
            car_model_year=car1.car_model_year
        ).filter(Car.data_requested_time >= last_3months).all()

        car_prices_last3Months = [int(x[0])
                                  for x in cars_with_same_model_last3Months]

        car_model_median_price_last3Months = statistics.median(
            car_prices_last3Months)

        # car_model_max_price

        car_model_max_price_last3Months = max(car_prices_last3Months)

        # car_model_min_price
        car_model_min_price_last3Months = min(car_prices_last3Months)

        # car_model_divergence_price

        car_model_divergence_price_last3Months = round(100 -
                                                       ((int(car1.car_price)/car_model_median_price_last3Months)*100), 2)

        car1.car_model_count_Last3Months = len(
            cars_with_same_model_last3Months)
        car1.car_model_median_price_Last3Months = car_model_median_price_last3Months
        car1.car_model_max_price_Last3Months = car_model_max_price_last3Months
        car1.car_model_min_price_Last3Months = car_model_min_price_last3Months
         car1.car_model_divergence_price_Last3Months = car_model_divergence_price_last3Months
          spider.logger.info(f"DATA PUSHED FOR Car ID => {car1_id}")
           try:
                session.commit()

            except:
                session.rollback()
                raise

            finally:
                spider.logger.info(
                    'Updating tables completed, closing the spider')
                session.close()
