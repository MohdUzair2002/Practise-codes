from sqlalchemy import create_engine, Column, Table, ForeignKey, MetaData
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import (
    Integer, String, Date, DateTime, Float, Boolean, Text)
from scrapy.utils.project import get_project_settings
import datetime as dt
from datetime import datetime
from sqlalchemy.sql import func
Base = declarative_base()


def db_connect():
    """
    Performs database connection using database settings from settings.py.
    Returns sqlalchemy engine instance
    """
    return create_engine(get_project_settings().get("CONNECTION_STRING"))


def create_table(engine):
    Base.metadata.create_all(engine)


class Add(Base):
    __tablename__ = "Adds"

    id = Column(Integer, primary_key=True)

    url = Column('url', Text())
    Title = Column('Title', Text())
    Price = Column('Price', Text())
    Description = Column('Description', Text())
    ProductID = Column('ProductID', Text())
    Sellername = Column('Sellername', Text())
    SellerID = Column('SellerID', Text())
    MainImage = Column('MainImage', Text())
    Image1 = Column('Image1', Text())
    Image2 = Column('Image2', Text())
    Image3 = Column('Image3', Text())
    Image4 = Column('Image4', Text())
    shipping = Column('shipping', Text())
    Date = Column('Date', Text())
