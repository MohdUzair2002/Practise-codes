# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import Join, MapCompose, TakeFirst


def take_number(text):
    numbers = "".join(list(filter(lambda x: x in '1234567890', text)))
    return numbers


class CrawlerItem(scrapy.Item):
    url = scrapy.Field()
    Title = scrapy.Field()
    Price = scrapy.Field()
    Description = scrapy.Field()
    ProductID = scrapy.Field()
    Sellername = scrapy.Field()
    SellerID = scrapy.Field()
    MainImage = scrapy.Field()
    Image1 = scrapy.Field()
    Image2 = scrapy.Field()
    Image3 = scrapy.Field()
    Image4 = scrapy.Field()
    shipping = scrapy.Field()
    Date = scrapy.Field()
