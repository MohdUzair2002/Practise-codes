from itertools import product
from urllib.parse import urljoin, urlparse
import scrapy
from Crawler.items import CrawlerItem
import re
from datetime import datetime
import logging
from scrapy.utils.log import configure_logging
from urllib.parse import urljoin


class cypherSpider(scrapy.Spider):

    # configure_logging(install_root_handler=False)
    # logging.basicConfig(
    #     filename='log.txt',
    #     format='%(levelname)s: %(message)s',
    #     level=logging.INFO
    # )
    name = 'americanas'

    error_count = 0

    # download_delay = 1

    # db = LightDB("cypher_vc_crypto.json")
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:97.0) Gecko/20100101 Firefox/97.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Referer': 'https://www.americanas.com.br/',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'If-None-Match': 'W/"920b0-r4F1aW4VVPGUx82CcYJ/tfctUf8"',
        'Cache-Control': 'max-age=0',
        'TE': 'trailers',
    }

    start_urls = [
        f'https://www.americanas.com.br/busca/maos?limit=50&offset={i}' for i in range(0, 1000, 50)
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def start_requests(self):
        for url in self.start_urls:

            yield scrapy.Request(url, callback=self.parse, headers=self.headers)

    def parse(self, response):

        # self.logger.info('Parse function called at {}'.format(response.url))
        product_urls = response.xpath(
            "//a[contains(@href,'/produto/')]/@href").extract()
        if product_urls:
            for item in product_urls:
                print(item)
                yield scrapy.Request(urljoin('https://www.americanas.com.br/', item), callback=self.parseAdd, headers=self.headers)

    def parseAdd(self, response):
        product = CrawlerItem()

        product["url"] = response.url

        now = datetime.now()
        product["Date"] = now.strftime("%d/%m/%Y %H:%M:%S")

        product["Title"] = response.xpath(
            "//h1[contains(@class,'product-title')]/text()").get()

        product["MainImage"] = response.xpath(
            "//div[contains(@class,'main-image')]//picture[contains(@class,'src__Picture')]/source/@srcset").get()

        product["Image1"] = response.xpath(
            "//div[contains(@class,'thumb-gallery')]/div[@src][1]/@src").get()
        product["Image2"] = response.xpath(
            "//div[contains(@class,'thumb-gallery')]/div[@src][2]/@src").get()
        product["Image3"] = response.xpath(
            "//div[contains(@class,'thumb-gallery')]/div[@src][3]/@src").get()
        product["Image4"] = response.xpath(
            "//div[contains(@class,'thumb-gallery')]/div[@src][4]/@src").get()

        price = response.xpath(
            "//div[contains(@class,'src__PriceWrapper')]//text()").extract()

        product["Price"] = "".join(price)

        prod_id = urlparse(response.url).path.split('/')[-1]

        product["ProductID"] = prod_id

        seller = response.xpath("//a[contains(@href,'/lojista')]")
        if seller:
            product["Sellername"] = seller.xpath('./text()').get()
            product["SellerID"] = seller.xpath('./@href').get().split('/')[-1]
        else:
            product["Sellername"] = "Americanas"
            product["SellerID"] = 0000

        product["shipping"] = False
        shipping = response.xpath('//*[text()="produto internacional"]')
        if shipping:
            product["shipping"] = True

        product["Description"] = response.xpath(
            "//p[contains(@class,'product-description')]/text()").get()

        yield product
